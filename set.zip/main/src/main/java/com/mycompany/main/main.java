// Класс узла списка
class Node {
    int data; // данные, хранимые в узле
    Node next; // ссылка на следующий узел

    // Конструктор узла
    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

// Класс для реализации структуры данных "Список"
public class LinkedList {
    private Node head; // ссылка на первый узел списка

    // Конструктор списка
    public LinkedList() {
        this.head = null;
    }

    // Метод для добавления элемента в конец списка
    public void add(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Метод для вывода списка
    public void printList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
    }

    // Пример использования
    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        list.add(1);
        list.add(2);
        list.add(3);

        System.out.print("Список: ");
        list.printList();
    }
}